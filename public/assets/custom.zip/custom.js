
      
$(document).ready(function() {
    var $menuToggle = $('#menu-toggle');
    var $closeSidebar = $('#close-sidebar');
    var $sidebar = $('#sidebar');
    var $wrapper = $('#wrapper');
    var $toggleIcon = $menuToggle.find('i'); // Select the icon inside the button

    // Default state: Sidebar is active (visible) on larger screens
    function checkScreenSize() {
        if ($(window).width() >= 992) {
            $sidebar.addClass("active"); // Active (visible) on large screens
            $wrapper.addClass("padding-left").removeClass("no-padding");
            $toggleIcon.removeClass('fa-times').addClass('fa-bars'); // Ensure correct icon on load
        } else {
            $sidebar.removeClass("active"); // Not active (hidden) on small screens
            $wrapper.addClass("no-padding").removeClass("padding-left");
            // $toggleIcon.removeClass('fa-bars').addClass('fa-times'); // Ensure correct icon on load
        }
    }

    // Run on initial load
    checkScreenSize();

    // Toggle sidebar visibility and icon on button click
    $menuToggle.on('click', function() {
        $sidebar.toggleClass("active");
        $wrapper.toggleClass("padding-left", $sidebar.hasClass("active"));
        $wrapper.toggleClass("no-padding", !$sidebar.hasClass("active"));

        // Change the icon based on sidebar state
        if ($sidebar.hasClass('active')) {
            $toggleIcon.removeClass('fa-bars').addClass('fa-times'); // Change to 'close' icon
        } else {
            $toggleIcon.removeClass('fa-times').addClass('fa-bars'); // Change to 'menu' icon
        }
    });

    // Close sidebar on close button click and reset the toggle icon
    $closeSidebar.on('click', function() {
        $sidebar.removeClass("active");
        $wrapper.addClass("no-padding").removeClass("padding-left");
        $toggleIcon.removeClass('fa-times').addClass('fa-bars'); // Change to 'menu' icon
    });

    // Run the check on window resize
    $(window).on('resize', checkScreenSize);
});


$(document).ready(function() {
    $('.sidemenu-toggle > a').on('click', function(event) {
        event.preventDefault(); 
        var $parentLi = $(this).parent(); 
        
        // Toggle the active class on the parent li
        $parentLi.toggleClass('active');
        
        // Slide toggle the submenu
        $parentLi.find('.pcoded-submenu').slideToggle();
    });

    $('.main_menu > li').on('click', function(event){
        $('.main_menu > li').removeClass('active'); 
        $(this).addClass('active'); 
    });

    $('.pcoded-submenu > li').on('click', function(event){
        $('.pcoded-submenu > li').removeClass('active'); 
        $(this).addClass('active'); 
    });


        $('.dropdownButton').click(function(){
          $(this).next('.dropdown-menu').toggle();
        });
      
});


